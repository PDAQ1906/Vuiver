package com.example.myloginapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity7 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);

        ImageView img_family = findViewById(R.id.img_family);
        img_family.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent it6 = new Intent(MainActivity7.this, MainActivity8.class);
                startActivity(it6);
            }
        });
    }
}